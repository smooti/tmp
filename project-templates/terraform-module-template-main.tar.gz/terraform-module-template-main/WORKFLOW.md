# Terraform Module Workflow

This document outlines the standard workflow for developing and contributing to this Terraform module.

## Quick Start

```bash
# Clone the repository
git clone <repo-url>
cd <repo>

# Install pre-commit hooks
pip install pre-commit
pre-commit install

# Create a feature branch
git checkout -b feature/your-feature-name
```

## Development Workflow

### 1. Branch Strategy

| Branch      | Purpose               | Protection    |
| ----------- | --------------------- | ------------- |
| `main`      | Production-ready code | Protected     |
| `feature/*` | New features          | Merge Request |
| `fix/*`     | Bug fixes             | Merge Request |

### 2. Making Changes

1. **Create branch** from `main`:
	```bash
	git checkout -b feature/your-feature
	```

2. **Make changes** following [STYLE.md](STYLE.md) standards

3. **Run linting**:

	```bash
	# Pre-commit hooks
	pre-commit run --all-files

	# TFLint
	tflint --config=.tflint.hcl
	```

4. **Update documentation** if modifying resources:

	```bash
	terraform-docs --config .terraform-docs.yml .
	```

---

**Note** - Documentation gets generated on merge request when terraform files have changed.

---

5. **Commit and push**:

	```bash
	git add .
	git commit -m "Description of changes"
	git push origin feature/your-feature
	```

6. **Create Merge Request** for review

## Required Tools

| Tool           | Version | Purpose                |
| -------------- | ------- | ---------------------- |
| Terraform      | >= 1.0  | Infrastructure as Code |
| TFLint         | >= 0.50 | Linting                |
| terraform-docs | >= 0.20 | Documentation          |
| pre-commit     | latest  | Git hooks              |

## File Structure

```foo
.
├── main.tf          # Core resource definitions
├── variables.tf     # Input variable declarations
├── outputs.tf       # Output definitions
├── versions.tf      # Version constraints
├── locals.tf        # Local values
├── README.md        # Module documentation
├── examples/        # Usage examples
├── .gitlab-ci.yml   # CI/CD pipeline
├── .tflint.hcl      # TFLint configuration
└── .pre-commit-config.yaml
```

## CI/CD Pipeline

The `.gitlab-ci.yml` runs:

- Linting (TFLint, terraform validate)
- Documentation generation
- Security scans

## Common Tasks

### Generate Documentation

```bash
terraform-docs --config .terraform-docs.yml .
```

### Run Linting

```bash
pre-commit run --all-files
tflint
```

### Validate Terraform

```bash
terraform init
terraform validate
terraform plan
```

### Format Code

```bash
terraform fmt -recursive
```
