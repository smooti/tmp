# Terraform Module Style Guide

This document defines the coding standards, structure, and best practices for creating and maintaining Terraform modules in this repository.

It is based on HashiCorp recommendations and extended with team-specific conventions to ensure consistency, readability, and maintainability.

---

**Note**
For the recommended pattern for Terraform module creation use the following as a [reference](https://developer.hashicorp.com/terraform/tutorials/modules/pattern-module-creation).

---

## Module Naming Convention

The Terraform registry requires that repositories match a naming convention for all modules that you publish to the registry. Module repositories must use this three-part name `terraform-<PROVIDER>-<NAME>`, where `<NAME>` reflects the type of infrastructure the module manages and `<PROVIDER>` is the main provider the module uses. The `<NAME>` segment can contain additional hyphens, for example, `terraform-google-vault` or `terraform-aws-ec2-instance`.

---

## Standard Module Structure

Each Terraform module **must** follow this structure:

```
.
├── main.tf
├── variables.tf
├── outputs.tf
├── versions.tf
├── providers.tf # optional (only if needed)
├── locals.tf # optional
├── data.tf # optional
├── README.md
├── examples/ # optional
│ └── basic/
│ └── main.tf
└── tests/ # optional (for future use)
```

| File           | Purpose                                    |
| -------------- | ------------------------------------------ |
| `main.tf`      | Core resource definitions                  |
| `variables.tf` | Input variable declarations                |
| `outputs.tf`   | Output definitions                         |
| `versions.tf`  | Terraform and provider version constraints |
| `providers.tf` | Provider configuration (if required)       |
| `locals.tf`    | Local values                               |
| `data.tf`      | Data sources                               |
| `README.md`    | Module documentation                       |
| `examples/`    | Usage examples                             |
