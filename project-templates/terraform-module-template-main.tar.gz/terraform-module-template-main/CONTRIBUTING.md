# Contributing to this Terraform Module

Thank you for your interest in contributing. This document outlines the guidelines for contributing to this repository, including style standards, formatting requirements, and documentation processes.

---

## Prerequisites

- [Terraform](https://www.terraform.io/downloads) >= 1.0
- [TFLint](https://github.com/terraform-linters/tflint) >= 0.50
- [terraform-docs](https://terraform-docs.io/) >= 0.20

---

## Development Workflow

1. **Create a feature branch** from `main`
2. **Make your changes** following the style guidelines
3. **Run linting** before committing
4. **Update documentation** if modifying resources
5. **Submit a merge request** for review

---

## Style Guidelines

All code must follow the [STYLE.md](STYLE.md) standards. Key points:

### Module Structure

```foo
.
├── main.tf          # Core resource definitions
├── variables.tf     # Input variable declarations
├── outputs.tf       # Output definitions
├── versions.tf      # Terraform and provider version constraints
├── data.tf          # Data sources (optional)
├── README.md        # Module documentation
└── examples/        # Usage examples
```

### Naming Conventions

- Module repositories must follow: `terraform-<PROVIDER>-<NAME>`
- Variables use snake_case: `vm_name`
- Resources use Terraform naming: `vsphere_virtual_machine`

### Code Standards

- Use explicit provider prefixes (e.g., `vsphere_virtual_machine`)
- Document all variables with descriptions
- Use `count` or `for_each` instead of hardcoded values
- Pin provider versions in `versions.tf`

---

## Formatting

### Terraform Formatting

Format all Terraform files before committing:

```bash
terraform fmt -recursive
```

### Linting

Run TFLint to catch issues:

```bash
tflint --init
tflint --recursive
```

The CI pipeline runs TFLint automatically on changes to `*.tf` files.

---

## Documentation

### Auto-Generated Documentation

This module uses [terraform-docs](https://terraform-docs.io/) to automatically generate the `README.md` from Terraform configuration.

**Configuration**: See [`.terraform-docs.yml`](.terraform-docs.yml)

### Generating Documentation

Run terraform-docs locally:

```bash
terraform-docs --config .terraform-docs.yml .
```

The GitLab CI pipeline automatically:

1. Runs `terraform-docs` when `*.tf` files change
2. Commits the updated `README.md` to the branch
3. Uploads the module to the Terraform registry on tags

### What gets documented

- `## Description` — Module overview
- `## Requirements` — Terraform and provider version constraints
- `## Providers` — Required providers
- `## Modules` — Child modules
- `## Resources` — All resources with descriptions
- `## Inputs` — Variable definitions with descriptions
- `## Outputs` — Output definitions with descriptions
- `## Example Usage` — Examples from `examples/`

---

## Versioning & Releases

This module follows [Semantic Versioning](https://semver.org/):

1. Create a git tag matching `^\d+\.\d+\.\d+$` (e.g., `1.2.3`)
2. Push the tag to trigger the release pipeline:

```bash
git tag -a 1.0.0 -m "Release v1.0.0"
git push origin 1.0.0
```

The release job uploads the module to the Terraform registry.

---

## Questions?

- Open an issue for bugs or feature requests
- Review existing issues before creating new ones
